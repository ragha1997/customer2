package com.capgemini.beans;

public class Bank {

	private Account[] accounts;
	
	public void showBalance(){
		double totalBalance = 0;
		
		for(int i = 0; i < accounts.length; i++)
		{
			totalBalance += accounts[i].getBalance();
		}
		
		System.out.println(totalBalance + ": total balance in bank");
	}
	
	
	
	public Bank() {
		accounts = new Account[5];
		
		for(int i = 0; i < accounts.length; i++){
			accounts[i] = new Account(5000, i);
		}
	}
	
//	synchronized
	public boolean transferAmount(int toAcc, int fromAcc, double amount) throws InterruptedException{

		synchronized(accounts[fromAcc]){
			synchronized (accounts[toAcc]) {
				
				if(accounts[fromAcc].getBalance() > amount){
					accounts[fromAcc].withdraw(amount);
					accounts[toAcc].deposit(amount);
				}else{
					return false;
				}
			}
		}
		return true;
	}
	
	
	
	
	
	
}
