package com.capgemini;

public class OddNosThread implements Runnable{

	@Override
	public void run() {
		int count = 0;
		
		for(;;count++){

			try{
				if(count %2 != 0){
					Thread.sleep(500);
					System.out.println(count + " in "+ Thread.currentThread().getName());
				}
			}catch(InterruptedException e){
				e.printStackTrace();
			}
		}
	
	}
	
	
	
}
