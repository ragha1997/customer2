import com.capgemini.Container;
import com.capgemini.Product;

class ProducerThread implements Runnable {
	private Container containerRef;

	public ProducerThread(Container containerRef) {
		super();
		this.containerRef = containerRef;
	}

	@Override
	public void run() {
		while (true) {
			System.out.println("PT scheduled...");
			try {
				containerRef.put(new Product("Mobile"));
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
	}
}

class ConsumerThread implements Runnable {

	private Container containerRef;

	public ConsumerThread(Container containerRef) {
		this.containerRef = containerRef;
	}

	@Override
	public void run() {

		while(true){
			System.out.println("CT scheduled...");
			try {
				containerRef.get();
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
	}
}
