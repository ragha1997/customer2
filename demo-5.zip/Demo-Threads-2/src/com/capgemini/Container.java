package com.capgemini;

public class Container {
	private Product[] products = new Product[1];
	private boolean isProductAvailable;
	
	synchronized
	public void put(Product product) throws InterruptedException{
		Thread.sleep(1200);
		
		while(isProductAvailable){
			this.wait();
		}
		
		if(!isProductAvailable){
			products[0] = product;
			isProductAvailable = true;
			this.notify();
		}
		System.out.println("Added product...");
	}
	
	synchronized
	public Product get() throws InterruptedException{
		Thread.sleep(10);
		
		while(!isProductAvailable){
			this.wait();
		}
		
		System.out.println("Retrieved product...");
		if(isProductAvailable){
			isProductAvailable =  false;
			this.notify();
			return products[0];
		}
		
		return null;
	}
	
	
	
	
}
