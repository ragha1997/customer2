import com.capgemini.beans.Bank;
import com.capgemini.utils.Teller;

public class Entry {

	public static void main(String[] args) throws InterruptedException {
		Bank bankRef = new Bank();

		bankRef.showBalance();
		
		Teller teller1 = new Teller(bankRef);
		Thread t1 = new Thread(teller1);
		t1.start();
		
		Teller teller2 = new Teller(bankRef);
		Thread t2 = new Thread(teller2);
		t2.start();
		
		t1.join();
		t2.join();
		
		bankRef.showBalance();
		
	}

}
