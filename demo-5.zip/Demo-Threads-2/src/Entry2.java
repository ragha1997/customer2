import com.capgemini.Container;

public class Entry2 {
	public static void main(String[] args) {
		Container containerRef = new Container();
		
		new Thread(new ProducerThread(containerRef))
			.start();
		
		new Thread(new ConsumerThread(containerRef))
		.start();
	}
}
