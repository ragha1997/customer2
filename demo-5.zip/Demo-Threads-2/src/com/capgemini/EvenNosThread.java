package com.capgemini;

public class EvenNosThread extends Thread{

	@Override
	public void run() /*throws InterruptedException*/{
		int count = 0;
		
		for(;;count++){
			
			try {
				if(count %2 == 0){
					Thread.sleep(800);
					System.out.println(count + " in "+ Thread.currentThread().getName());
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	
	}
	
	
	
}
