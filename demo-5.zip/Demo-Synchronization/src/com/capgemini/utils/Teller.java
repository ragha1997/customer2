package com.capgemini.utils;

import com.capgemini.beans.Bank;

public class Teller implements Runnable {

	private Bank bankRef;

	public Teller(Bank bankRef) {
		this.bankRef = bankRef;
	}

	@Override
	public void run() {
		try {
			performTransfer();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public boolean performTransfer() throws InterruptedException {
		
		for(int token = 0; token < 10; token++){
			int toAcc = (int)Math.floor(Math.random() * 5);
			int fromAcc = (int)Math.floor(Math.random() * 5);
			
			double amount = Math.floor(Math.random() * 5000);
			
			System.out.println("Transferring between "+ fromAcc + " & "+ toAcc);
			bankRef.transferAmount(toAcc, fromAcc, amount);
			
		}
			
		return true;
		
	}

}
