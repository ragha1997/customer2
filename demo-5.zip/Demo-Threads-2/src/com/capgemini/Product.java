package com.capgemini;

public class Product {

	private String name;

	public Product(String name) {
		this.name = name;
	}

}
